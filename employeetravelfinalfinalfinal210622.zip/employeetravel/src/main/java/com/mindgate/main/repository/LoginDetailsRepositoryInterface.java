package com.mindgate.main.repository;

import java.util.List;

import com.mindgate.main.pojo.LoginDetails;

public interface LoginDetailsRepositoryInterface {

	public LoginDetails getLoginDetailsByLoginId(int loginId);

	public List<LoginDetails> getAllLoginDetails();

	public LoginDetails login(LoginDetails loginDetails);

}
